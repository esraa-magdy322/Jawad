#-*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import hr_payroll_payslips_by_employees
from . import hr_payroll_index_wizard
from . import hr_payroll_edit_payslip_lines_wizard
