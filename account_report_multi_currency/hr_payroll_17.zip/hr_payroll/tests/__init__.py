# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_payslip_flow
from . import test_contract_calendar_2_weeks
from . import test_contract_schedule_change
from . import test_dashboard
from . import test_multi_contract
from . import test_rule_parameter
from . import test_payslip_computation
from . import test_performance
from . import test_work_entry
from . import test_resource
from . import test_schedule_relative_payslip
from . import test_salary_attachment
