# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_global_time_off
from . import test_work_entry
from . import test_work_intervals
